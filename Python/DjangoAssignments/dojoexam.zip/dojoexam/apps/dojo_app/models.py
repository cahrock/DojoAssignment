# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from ..login_app.models import User

#Create your models here.
class UserManager(models.Manager):
    def add_quote(self, _data):
        _error = {
            'flag': True,
            'err_message':[],
            'new_quote': ""
        }
        if len(_data['message']) == 0:
            _error['flag'] = False
            _error['err_message'].append("Your quote must not be blank.")
        if flag:
            _error['new_quote'] = self.create(quote = _data['message'])
            return _error

    def addtofav(self, _data):
        quote_ = self.filter(id = request.POST['message'])
        user_ = User.objects.filter(email = request.session['loggedin_user'])
        add_to_fav = Favorites.objects.create(user_com= user_[0], team= quote_[0])
        return add_to_fav



class Quotes(models.Model):
    user_id = models.ForeignKey(User, related_name='user_name')
    quote = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Favorites(models.Model):
    user_com = models.ForeignKey(User, related_name="user_comment")
    quote_com = models.ForeignKey(Quotes, related_name="quote_comment")
    comment = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
