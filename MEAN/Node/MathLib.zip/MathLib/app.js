var math_module = require('./math_module.js')();
console.log(math_module);
math_module.add(5,10);
math_module.multiply(5,10);
math_module.square(5);
math_module.random(10,2);
