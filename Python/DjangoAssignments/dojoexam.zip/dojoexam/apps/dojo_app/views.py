# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from models import Quotes, Favorites, UserManager
from ..login_app.models import User
from django.contrib import messages
from django.db.models import Count
from sets import Set

# Create your views here.
def quotes(request):
    add_quote = Quotes.objects.add_quote(request.POST)
    context={
        'quote': add_quote
    }
    return render(request, 'dojo_app/quotes.html', context)

def addfav(request):
    add_fav = Favorites.objects.addtofav(request.POST)
    context = {
        'fav': add_fav
    }
    return redirect('/quotes', context)

def removefromlist(request, _id):
    remove_list = Quotes.objects.filter(quote_com__id = _id).filter(user_com__email = request.session['loggedin_user']).delete()
    return redirect('/quotes')

def users(request):
    list_quotes = Quotes.objects.filter(user_id__email = request.session['loggedin_user']).order_by('-created_at')
    context = {
        'items': list_quotes
    }
    return redirect('/quotes', context)

def logout(request):
    request.session.clear()
    return redirect('/')
