public class SinglyLingkedList{
    public static void main(String[] args) {
        SinglyLingkedList sll = new SinglyLingkedList();
        sll.add(1);
        sll.add(2);
        sll.add(3);
        sll.add(4);
        sll.add(5);

        sll.remove();
        sll.printValue();
    }
}
