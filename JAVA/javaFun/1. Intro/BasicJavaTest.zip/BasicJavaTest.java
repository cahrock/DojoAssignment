class BasicJavaTest{

    public static void main(String[] args) {

        int[] arr = {1,4,5,-4,7,9};
        int num = 3;
        // BasicJava.printAllNumbers();
        // System.out.print("================");
        // System.out.print("\n");
        // BasicJava.printOddNumbers();
        // System.out.print("================");
        // System.out.print("\n");
        // BasicJava.printSum();
        // System.out.print("================");
        // System.out.print("\n");
        // BasicJava.iterateArray();
        // System.out.print("================");
        // System.out.print("\n");
        // BasicJava.findMax();
        // System.out.print("================");
        // System.out.print("\n");
        // BasicJava.getAverage();
        // BasicJava.arrOddNumber();
        // BasicJava.gTY(arr, num);
        // BasicJava.squareTheValue(arr);
        // BasicJava.elmNegNumber(arr);
        // BasicJava.maxMinAvg(arr);
        BasicJava.shiftingValues(arr);

    }
}
