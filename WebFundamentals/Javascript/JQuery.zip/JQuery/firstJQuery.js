<script type="text/javascript">
    $(document).ready(function(){
        $('#firstHide').hide()
    });
</script>
