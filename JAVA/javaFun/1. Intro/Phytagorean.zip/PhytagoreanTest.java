
class PhytagoreanTest{
    public static void main(String[] args) {
        System.out.println("Hypotenuse :" + Phytagorean.calculateHypotenuse(3,4));
    }
}
