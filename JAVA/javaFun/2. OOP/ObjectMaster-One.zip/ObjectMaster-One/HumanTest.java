public class HumanTest{
    public static void main(String[] args) {
        Human human = new Human();

    }
}
