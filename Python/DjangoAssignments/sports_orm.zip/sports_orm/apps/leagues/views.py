from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"pro_sport" : League.objects.filter(sport = "Baseball"),
		"Womens_league": League.objects.filter(name__contains='Womens'),
		"any_hockey": League.objects.filter(name__contains='Hockey'),
		'anything_but': League.objects.all().exclude(name__contains='Football'),
		'AllConferences': League.objects.filter(name__contains = "conference"),
		'location_dallas': Team.objects.filter(location__contains = 'Dallas'),
		'atlantic_reg': League.objects.filter(name__contains='Atlantic'),
		'raptors': Team.objects.filter(team_name__contains='Raptors'),
		"loc_city": Team.objects.filter(location__contains='City'),
		'beginT': Team.objects.filter(team_name__startswith="T"),
		'all_teams': Team.objects.all().order_by('location'),
		'all_teams_reverse': Team.objects.all().order_by('-team_name'),
		'cooper': Player.objects.filter(last_name__contains='Cooper'),
		'Joshua':
		Player.objects.filter(first_name__contains = 'Joshua'),
		'notJoshua': Player.objects.filter(last_name__contains='Cooper').exclude(first_name__contains = 'Joshua'),
		'alexWyatt': Player.objects.filter(first_name__contains='Alexander')|Player.objects.filter(first_name__contains='Wyatt')
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
