import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-angular-component',
  templateUrl: './first-angular-component.component.html',
  styleUrls: ['./first-angular-component.component.css']
})
export class FirstAngularComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
