from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^quotes$', views.quotes),
    url(r'^addfav$', views.addfav),
    url(r'^users$', views.users),
    url(r'^logout$', views.logout),
    url(r'^removefromlist/(?P<_id>\d+)$', views.removefromlist),
]
