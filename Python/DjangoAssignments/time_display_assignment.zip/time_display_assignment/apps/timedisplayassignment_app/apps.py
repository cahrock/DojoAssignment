# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class TimedisplayassignmentAppConfig(AppConfig):
    name = 'timedisplayassignment_app'
