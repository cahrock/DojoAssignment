from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):
	context = {
		"pro_sport" : League.objects.filter(sport = "Baseball"),
		"Womens_league": League.objects.filter(name__contains='Womens'),
		"any_hockey": League.objects.filter(name__contains='Hockey'),
		'anything_but': League.objects.all().exclude(name__contains='Football'),
		'AllConferences': League.objects.filter(name__contains = "conference"),
		'location_dallas': Team.objects.filter(location__contains = 'Dallas'),
		'atlantic_reg': League.objects.filter(name__contains='Atlantic'),
		'raptors': Team.objects.filter(team_name__contains='Raptors'),
		"loc_city": Team.objects.filter(location__contains='City'),
		'beginT': Team.objects.filter(team_name__startswith="T"),
		'all_teams': Team.objects.all().order_by('location'),
		'all_teams_reverse': Team.objects.all().order_by('-team_name'),
		'cooper': Player.objects.filter(last_name__contains='Cooper'),
		'Joshua':
		Player.objects.filter(first_name__contains = 'Joshua'),
		'notJoshua': Player.objects.filter(last_name__contains='Cooper').exclude(first_name__contains = 'Joshua'),
		'alexWyatt': Player.objects.filter(first_name__contains='Alexander')|Player.objects.filter(first_name__contains='Wyatt'),
		'atlantic_soccer_c': Team.objects.filter(league__name__contains='Atlantic Soccer Conference'),
		'penguins': Player.objects.filter(curr_team__team_name__contains='Penguins'),
		'all_players_col': Player.objects.filter(curr_team__league__name='International Collegiate Baseball Conference'),
		'lopez':Player.objects.filter(curr_team__league__name='American Conference of Amateur Footbal').filter(last_name__contains='Lopez'),
		'all_fp': Player.objects.all().filter(curr_team__league__sport='Football'),
		'allteam_sophia': Team.objects.filter(curr_players__first_name='Sophia'),
		'allleague_sophia': League.objects.filter(teams__curr_players__first_name='Sophia'),
		'flores': Player.objects.filter(last_name='Flores').exclude(curr_team__team_name='Washington Roughriders'),
		'samuel_evans': Player.objects.filter(first_name='Samuel', last_name='Evans'),
		'manitoba': Player.objects.filter(all_teams__team_name='Tiger-Cats'),
		'vikings': Player.objects.filter(all_teams__team_name='Vikings').exclude(curr_team__team_name='Vikings'),
		'jacob': Player.objects.filter(first_name='Jacob', last_name='Gray').exclude(all_teams__team_name='Colts'),
		'all_josh': Player.objects.filter(first_name='Joshua').filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players"),
		'allteams': Team.objects.annotate(num_players=Count('all_players')),
		'allplayers_': Player.objects.annotate(num_played=Count('all_teams')).order_by('-num_played')
	}

	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
